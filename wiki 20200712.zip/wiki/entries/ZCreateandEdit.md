# ZCreateandEdit

#Create - Save a new file 

#Edit update some file content

-what is the problem with this thing?