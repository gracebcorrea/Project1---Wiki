      # TestNewcontent

Heading level 1

===============



Heading level 2

---------------





List

I really like using Markdown.  

-This is the first line of the list.  

-And this is the second lineof the list.  







Bold

I just love **bold text**.  



I just love __bold text__.





Italicized text is the *cat's meow*.



Bold and italic

This text is ***really important***.



To create a blockquote, add a > in front of a paragraph.

>Do you like blockquote?







Blockquotes can contain multiple paragraphs. Add a > on the blank lines between the paragraphs.



> This will mark a hole paragrath.

>

> And if i whant to change the color?  

***I Love Chocolat***
   