MarkDown
Como transformar aquivos Markdown em Html e vice-versa?/r/n.

Markdown � uma linguagem simples de marca��o originalmente criada por John Gruber[1] e Aaron Swartz.[2] Markdown converte seu texto em HTML v�lido.

Texto com �nfase:

enfatizado (e.g., it�lico)

fortemente enfatizado (e.g., negrito)

C�digo:

codigo

Listas:

Um item em uma lista n�o ordenada

Outro item em uma lista n�o ordenada

Um item em uma lista ordenada

Outro item em uma lista ordenada

Cabe�alhos:

Cabe�alho de primeiro n�vel
Cabe�alho de quarto n�vel
Sintaxe alternativa para os dois primeiros cabe�alhos:

Cabe�alho de primeiro n�vel

====================

Cabe�alho de segundo n�vel

Cita��es:

Esse texto ser� envolto pelo elemento HTML blockquote.
