# Project1
New Version after 07/20

1)AlertsDjango.Html
  Any message cam be displayed usint this template.
2)NewPage.html
  Able user to insert new content to the encyclopedia
3)RandonPage.HTML

4)Index.HTML
5)
