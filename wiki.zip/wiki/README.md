# Project1
New Version after 07/20


###Work content

-Index.HTML
-Layout.HTML
-Entrypage.html
-NewPage.html
-SearchResults.Html
-EditPage.Html
-RandomPage.HTML
-View.py
-entries
